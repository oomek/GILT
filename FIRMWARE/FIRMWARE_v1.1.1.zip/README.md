UPDATING G.I.L.T. FIRMWARE
--------------------------

1. Connect G.I.L.T. to the usb port using a short cable provided.
2. Using a paperclip, or a sim card remover press once the button
   inside the pinhole on the bottom of the device.
3. Wait until Windows recognises the drivers for the uploader.
4. Double-click the UPDATE.bat file.

5. Once the update is done G.I.L.T. will restart with a new firmware.

You can confirm the firmware number on the G.I.L.T. debug screen:
1. Unplug the device from the USB.
2. Press and hold the G.I.L.T. button.
3. Plug in the usb cable back.
4. Release the button.

To exit from the debug screen you can either press and hold
the G.I.L.T. button, or unplug and plug back in the G.I.L.T. device.